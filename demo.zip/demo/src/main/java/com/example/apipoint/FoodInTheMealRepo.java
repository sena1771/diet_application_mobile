package com.example.apipoint;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FoodInTheMealRepo extends JpaRepository<FoodInTheMeal, Integer> {

}
