package com.example.apipoint;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MealTimeMealsRepo extends JpaRepository<MealTimesMeals, Integer> {

}