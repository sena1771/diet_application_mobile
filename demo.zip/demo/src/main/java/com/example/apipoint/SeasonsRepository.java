package com.example.apipoint;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SeasonsRepository extends JpaRepository<Seasons, Integer> {
}

