package com.example.apipoint;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MealsRepo extends JpaRepository<Meals, Integer>{

}
