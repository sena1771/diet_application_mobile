package com.example.apipoint;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DietTypesRepository extends JpaRepository<DietTypes, Integer> {
}
