package com.example.apipoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApipointApplicationTests {

	@Test
	void contextLoads() {
	}

}
